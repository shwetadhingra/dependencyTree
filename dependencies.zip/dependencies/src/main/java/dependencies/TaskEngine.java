package dependencies;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

// Shweta Dhingra
public class TaskEngine {
	
		public static final String file = "input.properties";
		private static BufferedReader buffer;
		private static Map<String, List<String>> installDependencies = new HashMap<String, List<String>>();
		private static Map<String, List<String>> reverseDependencies = new HashMap<String, List<String>>();
		private static Set<String> installs = new HashSet<String>();
		private static final String DEPEND = "DEPEND";
		private static final String INSTALL = "INSTALL";
		private static final String REMOVE = "REMOVE";
		private static final String LIST = "LIST";
		private static final String END = "END";
		
		//loading properties file
		
		static{
			InputStream stream = TaskEngine.class.getClassLoader().getResourceAsStream(file);
			if(stream != null){
				 buffer = new BufferedReader(new InputStreamReader(stream));
			} 
		}
		
		//reading properties file
		public static void getInput(){
			String cmd = null;
			try {
				while((cmd = buffer.readLine()) != null){
					if(cmd.equals("END")) {
						break;
					}
					System.out.println(cmd);
					
					performAction(cmd);
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//perform action based on the command
		public static void performAction(String cmd){
			String[] cmdType = (cmd.split("\\s+"));
			//System.out.println(TYPES.valueOf(cmdType[0]));
			String action = cmdType[0];
			List<String> args = new ArrayList<String>();
			
			for (int i = 1; i < cmdType.length; i++) {
				args.add(cmdType[i]);
			}
			
			if (action !=null) {
				if (action.equals(DEPEND)){
					runDependTaskEngine(args);
				} else if(action.equals(INSTALL)){
					runInstallTaskEngine(args, true);
				} else if(action.equals(REMOVE)){
					runRemoveTaskEngine(args);
				} else if(action.equals(LIST)){
					runListTaskEngine(args);
				} else {
					throw new IllegalArgumentException(action + ": Not Supported");
				}
			} else {
				throw new IllegalArgumentException("Invalid Input");
			}
		}
		
		//populate installDependencies map for tracking installation dependency
		public static void runDependTaskEngine(List<String> args){
			List<String> dependency = new ArrayList<String>();
			
			String arg = null;
			
			Iterator<String> iterator = args.iterator();
			if (iterator.hasNext()) {
				arg = iterator.next();
			}
			
			for ( ; iterator.hasNext() ;) {
				String argument = iterator.next(); 
				dependency.add(argument);
				addReverseDependency(argument, arg);
			}
			
			if (arg != null) {
				installDependencies.put(arg, dependency);
			}
		}
		
		//populate reverseDependencies map for maintaining index for removing dependencies
        private static void addReverseDependency(String argument, String arg) {
        	if (reverseDependencies.containsKey(argument)) {
        		reverseDependencies.get(argument).add(arg);
        	} else {
        		List<String> reverseDep = new ArrayList<String>();
        		reverseDep.add(arg);
        		reverseDependencies.put(argument, reverseDep );
        	}
        }
        	
		// install dependencies recursively before input installation
		public static void runInstallTaskEngine(List<String> args, boolean install) {
			
			if (args == null || args.size() > 1) {
				throw new IllegalArgumentException("INSTALL with no or multiple arguements not supported");
			}
			
			List<String> dependencies = installDependencies.get(args.get(0));
			
			if (dependencies == null) {
				install(args.get(0), install);
			} else {
				for (int i = 0; i < dependencies.size() ; i++) {
					List<String> installArg = new ArrayList<String>();
					installArg.add(dependencies.get(i));
					runInstallTaskEngine(installArg, false);
				}
				install(args.get(0), false);
			}
					
		}	
		
		//creating set of installations 
		private static void install(String arg, boolean install) {
			if (!installs.contains(arg)) {
				System.out.println("    Installing " + arg);
				installs.add(arg);
			} else if (install) {
				System.out.println("    " + arg + " is already installed");
			}
		}
		
		//list the installations
		public static void runListTaskEngine(List<String> args) {
			for (String s : installs) {
				System.out.println("    " + s);
			}
		}
		
		// removing only if dependencies are not installed
		public static void runRemoveTaskEngine(List<String> args) {
			if (args == null || args.size() > 1) {
				throw new IllegalArgumentException("REMOVE with no or multiple arguements not supported");
			}
			
			List<String> dependencies = reverseDependencies.get(args.get(0));
			
			if (dependencies == null) {
				remove(args.get(0));
			} else {
				for (int i = 0; i < dependencies.size() ; i++) {
					if (installs.contains(dependencies.get(i))) {
						System.out.println("    " + args.get(0) + " is still needed.");
						return;
					}
				}
				remove(args.get(0));
			}			
		}
		
		//remove from the reversedependenciesmap and installed set
		private static void remove(String arg) {
			if (installs.contains(arg)) {
				System.out.println("    Removing " + arg);
				installs.remove(arg);
				removeFromMaps(arg);
				removeParents(arg);
			} else {
				System.out.println("    " + arg + " is not installed");
			}
		}
		
		//remove from the reversedependenciesmap 
		private static void removeFromMaps(String arg) {
			List<String> dep = installDependencies.get(arg);
			if (dep == null || dep.size() == 0 ) {
				return;
			} else {
				for (int i = 0 ; i < dep.size() ; i ++) {
					reverseDependencies.get(dep.get(i)).remove(arg);
				}
			}
		}
		
		//remove dependency no longer related
		private static void removeParents(String arg) {
			List<String> dep = installDependencies.get(arg);
			if (dep == null || dep.size() == 0 ) {
				return;
			} else {
				List<String> reverseDep;
				for (int i = 0 ; i < dep.size() ; i ++) {
					reverseDep = reverseDependencies.get(dep.get(i));
					if (reverseDep == null || reverseDep.size() == 0) {
						remove(dep.get(i));
					}
				}
			}
		}
		
		//main method
		public static void main(String[] args){
			TaskEngine.getInput();
//			System.out.println("PRINTING MAP" + installDependencies);
//			System.out.println("PRINTING MAP" + reverseDependencies);
		}
		
		
		
}

